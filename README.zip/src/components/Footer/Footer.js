import React from 'react';

const Footer=()=> {
 
  return (
    <div className="col-md-12 footer">
        @Copy Right
    </div>
  );
}


export default Footer;